# my-reproducible manuscript

<!-- badges: start -->
<!-- badges: end -->

Goal: make a reproducible conpendium for the course Markup Languages and Reproducible Programming. 
Author: Heleen Brüggen
Date of creation: 08-01-2024