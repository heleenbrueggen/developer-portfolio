Goal: Creating a reproducible document from the Boulesteix et al. (2020)
Author: Heleen Brüggen
Date of creation: 9th January 2024
